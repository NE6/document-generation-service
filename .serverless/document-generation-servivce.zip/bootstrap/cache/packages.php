<?php return array (
  'bref/laravel-bridge' => 
  array (
    'providers' => 
    array (
      0 => 'Bref\\LaravelBridge\\BrefServiceProvider',
    ),
  ),
  'hammerstone/sidecar' => 
  array (
    'providers' => 
    array (
      0 => 'Hammerstone\\Sidecar\\Providers\\SidecarServiceProvider',
    ),
  ),
  'intervention/image' => 
  array (
    'providers' => 
    array (
      0 => 'Intervention\\Image\\ImageServiceProvider',
    ),
    'aliases' => 
    array (
      'Image' => 'Intervention\\Image\\Facades\\Image',
    ),
  ),
  'laravel/sail' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Sail\\SailServiceProvider',
    ),
  ),
  'laravel/sanctum' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Sanctum\\SanctumServiceProvider',
    ),
  ),
  'laravel/tinker' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Tinker\\TinkerServiceProvider',
    ),
  ),
  'nesbot/carbon' => 
  array (
    'providers' => 
    array (
      0 => 'Carbon\\Laravel\\ServiceProvider',
    ),
  ),
  'nunomaduro/collision' => 
  array (
    'providers' => 
    array (
      0 => 'NunoMaduro\\Collision\\Adapters\\Laravel\\CollisionServiceProvider',
    ),
  ),
  'nunomaduro/termwind' => 
  array (
    'providers' => 
    array (
      0 => 'Termwind\\Laravel\\TermwindServiceProvider',
    ),
  ),
  'spatie/laravel-ignition' => 
  array (
    'providers' => 
    array (
      0 => 'Spatie\\LaravelIgnition\\IgnitionServiceProvider',
    ),
    'aliases' => 
    array (
      'Flare' => 'Spatie\\LaravelIgnition\\Facades\\Flare',
    ),
  ),
  'wnx/sidecar-browsershot' => 
  array (
    'providers' => 
    array (
      0 => 'Wnx\\SidecarBrowsershot\\SidecarBrowsershotServiceProvider',
    ),
    'aliases' => 
    array (
      'SidecarBrowsershot' => 'Wnx\\SidecarBrowsershot\\Facades\\SidecarBrowsershot',
    ),
  ),
);